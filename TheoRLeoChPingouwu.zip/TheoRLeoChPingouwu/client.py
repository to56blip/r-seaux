import socket
import psycopg2
import csv
from os.path import exists
addr = ('',37020)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
#Enable broadcast mode
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
s.bind(addr)

conn = psycopg2.connect(dbname = 'PROJET_PEI', user = 'pguser' , password = 'pguser',host='192.168.30.122',port='5432')
cur = conn.cursor()
lieux_sensibles = "Serveur-O1 Serveur-002 Serveur-14 Serveur-13 Local-T117 Local-T007 Local-T011 Local-T201"
'''Cyberattack by broadcasting over the server
while 1:
	print("Attaque")
	s.sendto(b'HELLO WORLD !',('<broadcast>',37020))
'''
data = b'f'

def add_log_trace(fileName,id,date,heure,lieu):
	if not exists(f"{fileName}.csv"):
		with open(f'{fileName}.csv','w', newline='') as csvFile:
			sw = csv.writer(csvFile,delimiter=',')
			sw.writerow(["DATE","HEURE","ID","LIEU"])
	with open(f'{fileName}.csv','a', newline='') as csvFile:
		sw = csv.writer(csvFile,delimiter=',')
		sw.writerow([str(date),str(heure),str(id),str(lieu)])
def heureToSec(heure):
	h = list(map(int,heure.split(":")))
	return (h[0]*24+h[1])*60+h[2]

def ultraCritique(id,heure, date):
	lastDate = date
	lastSec = sec = heureToSec(heure)
	i = -2
	with open("log_trace.csv") as f:
		log = list(csv.reader(f))
		while date == lastDate and (sec-lastSec)<5:
			lastLine = log[i]
			if int(id)==int(lastLine[2]):
				return True
			lastSec = heureToSec(lastLine[1])
			lastDate = lastLine[0]
			i=i-1
	return False

while data:
	try:
		data,serv = s.recvfrom(2048)
		date,reste = data.decode().split(' ')
		heure,id,lieu=reste.split(',')
		add_log_trace("log_trace",id,date,heure,lieu)
		if ultraCritique(id,heure, date):
			print("ULTRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
			add_log_trace("log_ultra_critique",id,date,heure,lieu)
		cur.execute(f'SELECT "{lieu}" FROM "Acces_Bat" WHERE "ID" = {id}')
		acces = cur.fetchone()
		try:
			if acces[0]==True:
				print(f"{id} : You can go!")
			else:
				if lieu in lieux_sensibles:
					add_log_trace("log_sensibles",id,date,heure,lieu)
				add_log_trace("log_non_autorises",id,date,heure,lieu)
				print(f"{id} : Hey stop !")
		except:
			add_log_trace("log_critique",id,date,heure,lieu)
			print(f"{id} : Wtf who are you ?")
	except struct.error as err:
		print(f"Les données envoyées sont corrompues : {err}")
