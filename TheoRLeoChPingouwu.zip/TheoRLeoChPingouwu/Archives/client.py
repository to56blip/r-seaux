import socket
import psycopg2
import csv
from os.path import exists
addr = ('',37020)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
#Enable broadcast mode
s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
s.bind(addr)

conn = psycopg2.connect(dbname = 'PROJET_PEI', user = 'pguser' , password = 'pguser',host='192.168.30.122',port='5432')
cur = conn.cursor()

'''Cyberattack by broadcasting over the server
while 1:
	print("Attaque")
	s.sendto(b'HELLO WORLD !',('<broadcast>',37020))
'''
data = b'f'

def add_log_trace(id,date,heure,lieu):
	if not exists("log_trace.csv"):
		with open('log_trace.csv','w', newline='') as csvFile:
			sw = csv.writer(csvFile,delimiter=',')
			sw.writerow(["DATE","HEURE","ID","LIEU"])
	with open('log_trace.csv','a', newline='') as csvFile:
		sw = csv.writer(csvFile,delimiter=',')
		sw.writerow([str(date),str(heure),str(id),str(lieu)])
while data:
	try:
		data,serv = s.recvfrom(2048)
		date,reste = data.decode().split(' ')
		heure,id,lieu=reste.split(',')
		add_log_trace(id,date,heure,lieu)
		'''
		print(f'Date : {date}')
		print(f'Heure : {heure}')
		print(f'Id : {id}')
		print(f'Lieu : {lieu}')
		print("-----------")
		'''
		cur.execute(f'SELECT "{lieu}" FROM "Acces_Bat" WHERE "ID" = {id}')
		acces = cur.fetchone()
		try:
			if acces[0]==True:
				print(f"{id} : You can go!")
			else:
				print(f"{id} : Hey stop !")
		except:
			print(f"{id} : Wtf who are you ?")
	except struct.error as err:
		print(f"Les données envoyées sont corrompues : {err}")
