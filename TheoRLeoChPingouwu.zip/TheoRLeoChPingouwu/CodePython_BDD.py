import psycopg2

conn = psycopg2.connect(dbname = 'PROJET_PEI', user = 'pguser' , password = 'pguser',host='192.168.30.122',port='5432')
cur = conn.cursor()

#cur.execute('SELECT "Asc-2D" FROM "Acces_Bat" WHERE "ID" = 224529545')
cur.execute("SELECT * FROM information_schema.columns WHERE table_name='Acces_Bat'")
for a in cur.fetchall():
	print(a[3])


