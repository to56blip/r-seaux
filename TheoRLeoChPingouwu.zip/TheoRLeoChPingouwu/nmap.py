import socket
addr = '192.168.30.100'
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
for i in range(60000):
	try:
		s.connect((addr,i))
		print(f"it's working {i}")
	except:
		pass
