from flask import Flask
from flask import *

app = Flask(__name__)
app.secret_key = 'Hello'

@app.route('/')
def hello():
	b = [['DATE'],['Heure'],['id'],['lieu'],['DATE2'],['Heure2'],['id2'],['lieu2']]
	flash("Coucou","success")
	return render_template("about.html",badges = b, l = len(b))
