import threading
import socket
import psycopg2
import csv
from flask_socketio import *
from os.path import exists

def add_log_trace(fileName,id,date,heure,lieu,status):
	if not exists(f"{fileName}.csv"):
		with open(f'{fileName}.csv','w', newline='') as csvFile:
			sw = csv.writer(csvFile,delimiter=',')
			sw.writerow(["DATE","HEURE","ID","LIEU","STATUS"])
	with open(f'{fileName}.csv','a', newline='') as csvFile:
		sw = csv.writer(csvFile,delimiter=',')
		sw.writerow([str(date),str(heure),str(id),str(lieu),str(status)])
def heureToSec(heure):
	h = list(map(int,heure.split(":")))
	return (h[0]*24+h[1])*60+h[2]
def ultraCritique(id,heure, date):
	lastDate = date
	lastSec = sec = heureToSec(heure)
	i = -2
	with open("log_trace.csv") as f:
		log = list(csv.reader(f))
		while date == lastDate and (sec-lastSec)<5:
			lastLine = log[i]
			if int(id)==int(lastLine[2]):
				return True
			lastSec = heureToSec(lastLine[1])
			lastDate = lastLine[0]
			i=i-1
	return False

class ThreadClient(threading.Thread):
	def __init__(self, sio):
		threading.Thread.__init__(self)
		self.sio = sio

	def run(self):
		addr = ('',37020)
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
		#Enable broadcast mode
		s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST,1)
		s.bind(addr)

		conn = psycopg2.connect(dbname = 'PROJET_PEI', user = 'pguser' , password = 'pguser',host='192.168.30.122',port='5432')
		cur = conn.cursor()
		lieux_sensibles = "Serveur-O1 Serveur-002 Serveur-14 Serveur-13 Local-T117 Local-T007 Local-T011 Local-T201"
		data = b'f'
		pourcentage = {"ok":0,"no":0,"wtf":0}
		with open('log_trace.csv') as f:
			pourcentage['ok']=(len(list(csv.reader(f))))
		with open('log_non_autorises.csv') as f:
			pourcentage['no']=(len(list(csv.reader(f))))
		with open('log_critique.csv') as f:
			pourcentage['wtf']=(len(list(csv.reader(f))))
		lastId = 0
		lastLieu = ""
		isTheFirstOccurenceOfUltra = False
		while data:
			try:
				data,serv = s.recvfrom(2048)
				date,reste = data.decode().split(' ')
				heure,id,lieu=reste.split(',')
				if id==lastId and lieu==lastLieu:
					print("Spam detected")
				else:
					lastId = id
					lastLieu=lieu				
					if ultraCritique(id,heure, date):
						print("ULTRAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA")
						
						add_log_trace("log_ultra_critique",id,date,heure,lieu, "error")
						if not isTheFirstOccurenceOfUltra:
							self.sio.emit('ultra',{"id":id,"date":date,"heure":heure}, broadcast=True)
							isTheFirstOccurenceOfUltra=True
					else:
						isTheFirstOccurenceOfUltra=False
					cur.execute(f'SELECT "{lieu}" FROM "Acces_Bat" WHERE "ID" = {id}')
					acces = cur.fetchone()
					try:
						if acces[0]==True:
							add_log_trace("log_trace",id,date,heure,lieu,"ok")
							print(f"{id} {lieu}: You can go!")
							print(f"{lieu}: You can go!")
							pourcentage['ok']+=1
							self.sio.emit('log',{"date":date,"heure":heure,"id":id,"lieu":lieu,"pass":"green"}, broadcast=True)
							self.sio.emit('stats',pourcentage, broadcast=True)
						else:
							add_log_trace("log_trace",id,date,heure,lieu,"no")
							if lieu in lieux_sensibles:
								add_log_trace("log_sensibles",id,date,heure,lieu, "error")
							add_log_trace("log_non_autorises",id,date,heure,lieu, "error")
							print(f"{id} : Hey stop !")
							pourcentage['no']+=1
							self.sio.emit('log',{"date":date,"heure":heure,"id":id,"lieu":lieu,"pass":"orange"}, broadcast=True)
							self.sio.emit('stats',pourcentage, broadcast=True)
					except:
						add_log_trace("log_trace",id,date,heure,lieu,"wtf")
						add_log_trace("log_critique",id,date,heure,lieu, "error")
						pourcentage['wtf']+=1
						self.sio.emit('log',{"date":date,"heure":heure,"id":id,"lieu":lieu,"pass":"red"}, broadcast=True)
						self.sio.emit('stats',pourcentage, broadcast=True)
						print(f"{id} : Wtf who are you ?")
			except struct.error as err:
				print(f"Les données envoyées sont corrompues : {err}")
