salles = {"Portique-Nord": 0, "Portique-Est":0, "Portique-Ouest":0, "Portique-Sud":0, "Garage":0, "Sous-Sol-0A":0, "Sous-Sol-1A":0, "Sous-Sol-1B":0, "Sous-Sol-0C":0, "Porte-Service-11":0, "Porte-Service-12":0, "Porte-Service-13":0, "Porte-Service-21":0, "Porte-Service-41":0, "Porte-R":0, "Porte-C":0, "Porte-1Z":0, "Porte-34E":0, "Salle-106":0, "Salle-107":0, "Salle-201":0, "Salle-310":0, "Salle-401":0, "Serveur-01":0, "Serveur-002":0, "Serveur-14":0, "Serveur-13":0, "Bureau-A13":0, "Bureau-T21":0, "Bureau-309":0, "Bureau-101":0, "Bureau-401":0, "Local-T117":0, "Local-T007":0, "Local-T011":0, "Local-T201":0, "Asc-1A":0, "Asc-1B":0, "Asc-2C":0, "Asc-2D":0}

print(len(salles))
i = 0
for l in salles:
	print("{ y: {{s["+ str(i) +"]}}, label: \"" + l + "\" },")
	i += 1
